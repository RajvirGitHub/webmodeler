'use strict';

var config = {};
config.camundaEngine = {};
config.localhost = {};
config.services = {};

// CamundaEngine host and port means Running Camunda Engine Server's Host IP and PORT number
config.camundaEngine.host = '10.10.221.3';
config.camundaEngine.port=  '8080';
//for running BPMN WEB Modeler on your local or Ubuntu system provide machine IP/HOST and PORT number 
config.localhost.host = '10.10.221.3';
config.localhost.port = '9005';
//Custom Services Deployed Configuration
//for TICKET SERVICES:

config.services.GETTICKETSERVICE =  'CallingGet-TicketService';
config.services.UPDATETICKETSERVICE =  'CallingUpdate-TicketService';
config.services.SEARCHTICKETSERVICE =  'CallingSearch-TicketService';
config.services.CREATETICKETSERVICE =  'CallingCreate-TicketService';

//for MOBILITY EQUIPMENT SERVICES:
config.services.MOBILITYEQUIPMENTSERVICE =  'CallingMobility-EquipmentService';

//for A-AI SERVICE:
config.services.AAISERVICE =  'CallingA-AIService';

// for KAFKA ADAPTOR SERVICES:
config.services.KAFKASERVICE =  'CallingKafkaAdaptorService';
module.exports = config;